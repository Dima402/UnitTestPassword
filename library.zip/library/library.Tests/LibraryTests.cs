﻿using System;
using System.Text.RegularExpressions;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace library.Tests
{
    [TestClass]
    public class LibraryTests
    {
        bool result = false;

        [TestMethod]
        public void Letters()
        { 
            bool expected = true;
            String c = new String();
            bool actual = c.First(result);
            Assert.AreEqual(expected, actual);
        }

        [TestMethod]
        public void Digits()
        {
            bool expected = true;
            String c = new String();
            bool actual = c.Second(result);
            Assert.AreEqual(expected, actual);
        }

        [TestMethod]
        public void NotRussianLanguage()
        {
            bool expected = true;
            String c = new String();
            bool actual = c.Third(result);
            Assert.AreEqual(expected, actual);
        }

        [TestMethod]
        public void UpRegistr()
        {
            bool expected = true;
            String c = new String();
            bool actual = c.Fourth(result);
            Assert.AreEqual(expected, actual);
        }

        [TestMethod]
        public void Length()
        {
            bool expected = true;
            String c = new String();
            bool actual = c.Fifth(result);
            Assert.AreEqual(expected, actual);
        }
    }
}
